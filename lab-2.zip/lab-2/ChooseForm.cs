namespace Lab2;

public class ChooseForm : Form
{
    public ChooseForm()
    {
        Text = "Choose";
        ClientSize = new Size(320, 160);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;

        var lblTitle = new Label { Text = "What do you want to do?", Font = new Font("Segoe UI", 12, FontStyle.Bold), Location = new Point(20, 20), AutoSize = true };

        var btnBicycle = new Button { Text = "Bicycle", Location = new Point(30, 70), Size = new Size(120, 45) };
        var btnMushroom = new Button { Text = "Mushroom", Location = new Point(170, 70), Size = new Size(120, 45) };

        btnBicycle.Click += (s, e) => NavContext.Instance.Switch(new BicycleForm());
        btnMushroom.Click += (s, e) => NavContext.Instance.Switch(new MushroomForm());

        Controls.AddRange(new Control[] { lblTitle, btnBicycle, btnMushroom });
    }
}
