namespace Lab2;

public class BicycleForm : Form
{
    // Price per hour (RWF). Adjust to match your Lab 1 console prices.
    private static readonly (string Name, decimal PricePerHour)[] Bikes =
    {
        ("City bike", 1000m),
        ("Mountain bike", 1500m),
        ("Electric bike", 3000m),
    };

    private const int MaxHours = 72;

    private readonly ComboBox cmbType = new ComboBox();
    private readonly TextBox txtHours = new TextBox();
    private readonly TextBox txtTotal = new TextBox();
    private readonly ListBox lstRentals = new ListBox();
    private decimal total = 0m;

    public BicycleForm()
    {
        Text = "Bicycle Renting";
        ClientSize = new Size(420, 400);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;

        var lblTitle = new Label { Text = "Bicycle Renting", Font = new Font("Segoe UI", 14, FontStyle.Bold), Location = new Point(20, 15), AutoSize = true };
        var lblType = new Label { Text = "Bicycle type:", Location = new Point(20, 65), AutoSize = true };
        var lblHours = new Label { Text = "Hours:", Location = new Point(20, 100), AutoSize = true };

        cmbType.Location = new Point(120, 60);
        cmbType.Width = 270;
        cmbType.DropDownStyle = ComboBoxStyle.DropDownList;
        foreach (var b in Bikes)
            cmbType.Items.Add($"{b.Name} - {b.PricePerHour:N0} RWF/hour");
        cmbType.SelectedIndex = 0;

        txtHours.Location = new Point(120, 96);
        txtHours.Width = 100;

        var btnRent = new Button { Text = "Rent", Location = new Point(240, 94), Width = 70 };
        var btnClear = new Button { Text = "Clear", Location = new Point(320, 94), Width = 70 };
        btnRent.Click += BtnRent_Click;
        btnClear.Click += BtnClear_Click;

        lstRentals.Location = new Point(20, 140);
        lstRentals.Size = new Size(370, 130);

        var lblTotal = new Label { Text = "Total:", Location = new Point(20, 290), AutoSize = true };
        txtTotal.Location = new Point(120, 286);
        txtTotal.Width = 150;
        txtTotal.ReadOnly = true;
        txtTotal.Text = "0 RWF";

        var btnBack = new Button { Text = "Back", Location = new Point(20, 345), Width = 100 };
        var btnLogout = new Button { Text = "Logout", Location = new Point(290, 345), Width = 100 };
        btnBack.Click += (s, e) => NavContext.Instance.Switch(new ChooseForm());
        btnLogout.Click += (s, e) => NavContext.Instance.Switch(new LoginForm());

        Controls.AddRange(new Control[]
        {
            lblTitle, lblType, lblHours, cmbType, txtHours, btnRent, btnClear,
            lstRentals, lblTotal, txtTotal, btnBack, btnLogout
        });
        AcceptButton = btnRent;
    }

    private void BtnRent_Click(object sender, EventArgs e)
    {
        string input = txtHours.Text.Trim();

        if (input.Length == 0)
        {
            MessageBox.Show("Please enter the number of hours.", "Bicycle", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtHours.Focus();
            return;
        }

        if (!int.TryParse(input, out int hours))
        {
            MessageBox.Show("Hours must be a whole number (e.g. 3).", "Bicycle", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtHours.SelectAll();
            txtHours.Focus();
            return;
        }

        if (hours <= 0)
        {
            MessageBox.Show("Hours must be greater than 0.", "Bicycle", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtHours.SelectAll();
            txtHours.Focus();
            return;
        }

        if (hours > MaxHours)
        {
            MessageBox.Show($"You cannot rent for more than {MaxHours} hours at once.", "Bicycle", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtHours.SelectAll();
            txtHours.Focus();
            return;
        }

        var bike = Bikes[cmbType.SelectedIndex];
        decimal cost = bike.PricePerHour * hours;
        total += cost;

        lstRentals.Items.Add($"{bike.Name} x {hours}h = {cost:N0} RWF");
        txtTotal.Text = $"{total:N0} RWF";
        txtHours.Clear();
        txtHours.Focus();

        MessageBox.Show($"Rented {bike.Name} for {hours} hour(s).\nCost: {cost:N0} RWF",
            "Rental confirmed", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void BtnClear_Click(object sender, EventArgs e)
    {
        if (lstRentals.Items.Count == 0)
        {
            MessageBox.Show("There is nothing to clear.", "Bicycle", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        total = 0m;
        lstRentals.Items.Clear();
        txtTotal.Text = "0 RWF";
        txtHours.Clear();
    }
}
