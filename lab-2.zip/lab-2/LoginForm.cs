namespace Lab2;

public class LoginForm : Form
{
    private readonly TextBox txtUsername = new TextBox();
    private readonly TextBox txtPassword = new TextBox();
    private readonly Button btnLogin = new Button();

    public LoginForm()
    {
        Text = "Login";
        ClientSize = new Size(320, 200);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;

        var lblTitle = new Label { Text = "Login", Font = new Font("Segoe UI", 14, FontStyle.Bold), Location = new Point(20, 15), AutoSize = true };
        var lblUser = new Label { Text = "Username:", Location = new Point(20, 62), AutoSize = true };
        var lblPass = new Label { Text = "Password:", Location = new Point(20, 98), AutoSize = true };

        txtUsername.Location = new Point(110, 58);
        txtUsername.Width = 180;

        txtPassword.Location = new Point(110, 94);
        txtPassword.Width = 180;
        txtPassword.UseSystemPasswordChar = true;

        btnLogin.Text = "Login";
        btnLogin.Location = new Point(110, 140);
        btnLogin.Width = 100;
        btnLogin.Click += BtnLogin_Click;

        Controls.AddRange(new Control[] { lblTitle, lblUser, lblPass, txtUsername, txtPassword, btnLogin });
        AcceptButton = btnLogin; // Enter key = Login
    }

    private void BtnLogin_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtUsername.Text))
        {
            MessageBox.Show("Username cannot be empty.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtUsername.Focus();
            return;
        }

        if (string.IsNullOrWhiteSpace(txtPassword.Text))
        {
            MessageBox.Show("Password cannot be empty.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtPassword.Focus();
            return;
        }

        MessageBox.Show($"Welcome, {txtUsername.Text.Trim()}!", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
        NavContext.Instance.Switch(new ChooseForm());
    }
}
