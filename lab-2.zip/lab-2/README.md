# Lab 2 - Bicycle Renting & Mushroom (Windows Forms)

C# (.NET 8) desktop application converted from the Lab 1 console apps.

## Forms
- **Login** - username and password must not be empty.
- **Choose** - Bicycle or Mushroom.
- **Bicycle** - pick a bike type, enter hours, Rent adds to the running Total. Back / Logout.
- **Mushroom** - pick a type, enter weight, Calculate shows the price. Back / Logout.

## Navigation
Login -> Choose -> Bicycle / Mushroom. Back returns to Choose, Logout returns to Login.

## Run
Requires the .NET 8 SDK on Windows.

    dotnet run

Or open `Lab2.csproj` in Visual Studio 2022 and press F5.
