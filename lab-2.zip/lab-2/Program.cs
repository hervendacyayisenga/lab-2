namespace Lab2;

/// <summary>
/// Keeps exactly one form open at a time. Switch() shows the next form
/// and closes the previous one, so the app only exits when the user
/// closes the form that is currently on screen.
/// </summary>
public class NavContext : ApplicationContext
{
    public static NavContext Instance { get; private set; }

    public NavContext(Form first) : base(first)
    {
        Instance = this;
    }

    public void Switch(Form next)
    {
        Form old = MainForm;
        MainForm = next;   // ApplicationContext now watches 'next' for closing
        next.Show();
        old?.Close();
    }
}

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new NavContext(new LoginForm()));
    }
}
