namespace Lab2;

public class MushroomForm : Form
{
    // Price per kg (RWF). Adjust to match your Lab 1 console logic.
    private static readonly (string Name, decimal PricePerKg)[] Mushrooms =
    {
        ("Button mushroom", 4000m),
        ("Oyster mushroom", 6000m),
        ("Shiitake mushroom", 9000m),
    };

    private const decimal MaxKg = 100m;

    private readonly ComboBox cmbType = new ComboBox();
    private readonly TextBox txtWeight = new TextBox();

    public MushroomForm()
    {
        Text = "Mushroom";
        ClientSize = new Size(420, 260);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;

        var lblTitle = new Label { Text = "Mushroom", Font = new Font("Segoe UI", 14, FontStyle.Bold), Location = new Point(20, 15), AutoSize = true };
        var lblType = new Label { Text = "Type:", Location = new Point(20, 70), AutoSize = true };
        var lblWeight = new Label { Text = "Weight (kg):", Location = new Point(20, 110), AutoSize = true };

        cmbType.Location = new Point(120, 66);
        cmbType.Width = 270;
        cmbType.DropDownStyle = ComboBoxStyle.DropDownList;
        foreach (var m in Mushrooms)
            cmbType.Items.Add($"{m.Name} - {m.PricePerKg:N0} RWF/kg");
        cmbType.SelectedIndex = 0;

        txtWeight.Location = new Point(120, 106);
        txtWeight.Width = 100;

        var btnCalc = new Button { Text = "Calculate", Location = new Point(240, 104), Width = 100 };
        btnCalc.Click += BtnCalc_Click;

        var btnBack = new Button { Text = "Back", Location = new Point(20, 205), Width = 100 };
        var btnLogout = new Button { Text = "Logout", Location = new Point(290, 205), Width = 100 };
        btnBack.Click += (s, e) => NavContext.Instance.Switch(new ChooseForm());
        btnLogout.Click += (s, e) => NavContext.Instance.Switch(new LoginForm());

        Controls.AddRange(new Control[] { lblTitle, lblType, lblWeight, cmbType, txtWeight, btnCalc, btnBack, btnLogout });
        AcceptButton = btnCalc;
    }

    private void BtnCalc_Click(object sender, EventArgs e)
    {
        string input = txtWeight.Text.Trim();

        if (input.Length == 0)
        {
            MessageBox.Show("Please enter the weight in kg.", "Mushroom", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtWeight.Focus();
            return;
        }

        if (!decimal.TryParse(input, out decimal kg))
        {
            MessageBox.Show("Weight must be a number (e.g. 2.5).", "Mushroom", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtWeight.SelectAll();
            txtWeight.Focus();
            return;
        }

        if (kg <= 0)
        {
            MessageBox.Show("Weight must be greater than 0.", "Mushroom", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtWeight.SelectAll();
            txtWeight.Focus();
            return;
        }

        if (kg > MaxKg)
        {
            MessageBox.Show($"Maximum order is {MaxKg} kg.", "Mushroom", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtWeight.SelectAll();
            txtWeight.Focus();
            return;
        }

        var m = Mushrooms[cmbType.SelectedIndex];
        decimal cost = m.PricePerKg * kg;

        MessageBox.Show($"{m.Name}\n{kg} kg x {m.PricePerKg:N0} RWF = {cost:N0} RWF",
            "Mushroom total", MessageBoxButtons.OK, MessageBoxIcon.Information);
        txtWeight.Clear();
        txtWeight.Focus();
    }
}
